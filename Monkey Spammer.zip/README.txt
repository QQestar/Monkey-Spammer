🐵 Monkey Spammer - Automated Message Sender
===========================================
Monkey Spammer is an efficient spambot designed for automation, featuring a sleek GUI for sending automated messages. Perfect for testing, automation, or entertainment.

📌 Features:
- Modern GUI (customtkinter)
- Customizable message input (multiple lines)
- Set message multiplier & adjustable delay
- Built-in confirmation before spamming
- Fully standalone EXE (no dependencies required)

📥 Installation:
1. Extract the "Monkey Spammer.zip" file.
2. Simply run "Monkey Spammer.exe". No additional setup needed.

🚀 How to Use:
1. Open MonkeySpammer.exe
2. Enter your messages (one per line)
3. Set multiplier (number of repetitions)
4. Set delay (time between messages)
5. Click "Start Spamming" and confirm

⚠️ Disclaimer:
This tool is for educational and automation purposes only. The developer is not responsible for misuse.

👤 Developer:
Created by Quranul Islam Sahed
Contact: sahed016sahed@gmail.com
Date: March 8, 2025
